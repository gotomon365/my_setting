﻿namespace WindowsFormsApp2
{
    partial class BASE
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView_701 = new System.Windows.Forms.DataGridView();
            this.CLASS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NUMBER = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView_702 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView_902 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView_801 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView_901 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView_802 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView_final = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toExxcelButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button_help = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_701)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_702)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_902)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_801)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_901)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_802)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_final)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_701
            // 
            this.dataGridView_701.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_701.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CLASS,
            this.NUMBER,
            this.NAME});
            this.dataGridView_701.Location = new System.Drawing.Point(12, 12);
            this.dataGridView_701.Name = "dataGridView_701";
            this.dataGridView_701.RowTemplate.Height = 24;
            this.dataGridView_701.Size = new System.Drawing.Size(226, 146);
            this.dataGridView_701.TabIndex = 0;
            this.dataGridView_701.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_701_CellClick);
            // 
            // CLASS
            // 
            this.CLASS.HeaderText = "班級";
            this.CLASS.Name = "CLASS";
            this.CLASS.Width = 50;
            // 
            // NUMBER
            // 
            this.NUMBER.HeaderText = "座號";
            this.NUMBER.Name = "NUMBER";
            this.NUMBER.Width = 30;
            // 
            // NAME
            // 
            this.NAME.HeaderText = "姓名";
            this.NAME.Name = "NAME";
            // 
            // dataGridView_702
            // 
            this.dataGridView_702.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_702.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.dataGridView_702.Location = new System.Drawing.Point(244, 12);
            this.dataGridView_702.Name = "dataGridView_702";
            this.dataGridView_702.RowTemplate.Height = 24;
            this.dataGridView_702.Size = new System.Drawing.Size(226, 146);
            this.dataGridView_702.TabIndex = 0;
            this.dataGridView_702.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_702_CellClick_1);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "班級";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 50;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "座號";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 30;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "姓名";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridView_902
            // 
            this.dataGridView_902.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_902.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.dataGridView_902.Location = new System.Drawing.Point(244, 316);
            this.dataGridView_902.Name = "dataGridView_902";
            this.dataGridView_902.RowTemplate.Height = 24;
            this.dataGridView_902.Size = new System.Drawing.Size(226, 146);
            this.dataGridView_902.TabIndex = 0;
            this.dataGridView_902.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_902_CellClick);
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "班級";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 50;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "座號";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 30;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "姓名";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridView_801
            // 
            this.dataGridView_801.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_801.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.dataGridView_801.Location = new System.Drawing.Point(12, 164);
            this.dataGridView_801.Name = "dataGridView_801";
            this.dataGridView_801.RowTemplate.Height = 24;
            this.dataGridView_801.Size = new System.Drawing.Size(226, 146);
            this.dataGridView_801.TabIndex = 0;
            this.dataGridView_801.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_801_CellClick_1);
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "班級";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 50;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "座號";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Width = 30;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "姓名";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridView_901
            // 
            this.dataGridView_901.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_901.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.dataGridView_901.Location = new System.Drawing.Point(12, 316);
            this.dataGridView_901.Name = "dataGridView_901";
            this.dataGridView_901.RowTemplate.Height = 24;
            this.dataGridView_901.Size = new System.Drawing.Size(226, 146);
            this.dataGridView_901.TabIndex = 0;
            this.dataGridView_901.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_901_CellClick_1);
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "班級";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.Width = 50;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "座號";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.Width = 30;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "姓名";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridView_802
            // 
            this.dataGridView_802.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_802.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15});
            this.dataGridView_802.Location = new System.Drawing.Point(244, 164);
            this.dataGridView_802.Name = "dataGridView_802";
            this.dataGridView_802.RowTemplate.Height = 24;
            this.dataGridView_802.Size = new System.Drawing.Size(226, 146);
            this.dataGridView_802.TabIndex = 0;
            this.dataGridView_802.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_802_CellClick_1);
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.HeaderText = "班級";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.Width = 50;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.HeaderText = "座號";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.Width = 30;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.HeaderText = "姓名";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridView_final
            // 
            this.dataGridView_final.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_final.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18});
            this.dataGridView_final.Location = new System.Drawing.Point(494, 28);
            this.dataGridView_final.Name = "dataGridView_final";
            this.dataGridView_final.RowTemplate.Height = 24;
            this.dataGridView_final.Size = new System.Drawing.Size(230, 415);
            this.dataGridView_final.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "編號";
            this.Column1.Name = "Column1";
            this.Column1.Width = 20;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.HeaderText = "班級";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.Width = 50;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.HeaderText = "座號";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.Width = 30;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.HeaderText = "姓名";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // toExxcelButton
            // 
            this.toExxcelButton.Location = new System.Drawing.Point(761, 341);
            this.toExxcelButton.Name = "toExxcelButton";
            this.toExxcelButton.Size = new System.Drawing.Size(88, 37);
            this.toExxcelButton.TabIndex = 1;
            this.toExxcelButton.Text = " CLEAR";
            this.toExxcelButton.UseVisualStyleBackColor = true;
            this.toExxcelButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "label1";
            // 
            // button_help
            // 
            this.button_help.Location = new System.Drawing.Point(747, 28);
            this.button_help.Name = "button_help";
            this.button_help.Size = new System.Drawing.Size(111, 64);
            this.button_help.TabIndex = 3;
            this.button_help.Text = "<<使用說明>>";
            this.button_help.UseVisualStyleBackColor = true;
            this.button_help.Click += new System.EventHandler(this.button_help_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(761, 246);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 51);
            this.button1.TabIndex = 4;
            this.button1.Text = "複製到剪貼簿";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // BASE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 561);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button_help);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.toExxcelButton);
            this.Controls.Add(this.dataGridView_final);
            this.Controls.Add(this.dataGridView_901);
            this.Controls.Add(this.dataGridView_902);
            this.Controls.Add(this.dataGridView_801);
            this.Controls.Add(this.dataGridView_802);
            this.Controls.Add(this.dataGridView_702);
            this.Controls.Add(this.dataGridView_701);
            this.Name = "BASE";
            this.Text = "獎系統 .1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_701)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_702)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_902)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_801)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_901)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_802)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_final)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_701;
        private System.Windows.Forms.DataGridViewTextBoxColumn CLASS;
        private System.Windows.Forms.DataGridViewTextBoxColumn NUMBER;
        private System.Windows.Forms.DataGridViewTextBoxColumn NAME;
        private System.Windows.Forms.DataGridView dataGridView_702;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridView dataGridView_902;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridView dataGridView_801;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridView dataGridView_901;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridView dataGridView_802;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridView dataGridView_final;
        private System.Windows.Forms.Button toExxcelButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_help;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.Button button1;
    }
}

