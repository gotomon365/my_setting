﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;


namespace WindowsFormsApp2
{

    
    public partial class BASE : Form
    {
        public BASE()
        {
            InitializeComponent();

            //row701
            this.dataGridView_701.Rows.Add(701, 1, "王旻緯");
            this.dataGridView_701.Rows.Add(701, 2, "成柏諭");
            this.dataGridView_701.Rows.Add(701, 3, "吳承諭");
            this.dataGridView_701.Rows.Add(701, 4, "吳倬源");
            this.dataGridView_701.Rows.Add(701, 5, "李少元");
            this.dataGridView_701.Rows.Add(701, 6, "林長宏");
            this.dataGridView_701.Rows.Add(701, 7, "洪均磊");
            this.dataGridView_701.Rows.Add(701, 8, "洪瑞宏");
            this.dataGridView_701.Rows.Add(701, 9, "許至愷");
            this.dataGridView_701.Rows.Add(701, 10, "陳良輝");
            this.dataGridView_701.Rows.Add(701, 11, "曾昱瑜");
            this.dataGridView_701.Rows.Add(701, 12, "趙尹辰");
            this.dataGridView_701.Rows.Add(701, 13, "朱梅君");
            this.dataGridView_701.Rows.Add(701, 14, "吳霈恩");
            this.dataGridView_701.Rows.Add(701, 15, "李恩琪");
            this.dataGridView_701.Rows.Add(701, 16, "辛品囷");
            this.dataGridView_701.Rows.Add(701, 17, "林品瑩");
            this.dataGridView_701.Rows.Add(701, 18, "洪羽芯");
            this.dataGridView_701.Rows.Add(701, 19, "洪芷芸");
            this.dataGridView_701.Rows.Add(701, 20, "陳禹卉");
            this.dataGridView_701.Rows.Add(701, 21, "陳珈瑜");
            this.dataGridView_701.Rows.Add(701, 22, "歐盈妤");
            this.dataGridView_701.Rows.Add(701, 23, "林煜翔");


            // 702
            this.dataGridView_702.Rows.Add(702, 1, "王奕閎");
            this.dataGridView_702.Rows.Add(702, 2, "成俊廷");
            this.dataGridView_702.Rows.Add(702, 3, "成柏言");
            this.dataGridView_702.Rows.Add(702, 4, "呂亭晉");
            this.dataGridView_702.Rows.Add(702, 5, "呂振宇");
            this.dataGridView_702.Rows.Add(702, 6, "李宇正");
            this.dataGridView_702.Rows.Add(702, 7, "施宇祥");
            this.dataGridView_702.Rows.Add(702, 8, "洪奕哲");
            this.dataGridView_702.Rows.Add(702, 9, "洪紹淇");
            this.dataGridView_702.Rows.Add(702, 10, "趙家隆");
            this.dataGridView_702.Rows.Add(702, 11, "吳芸瑄");
            this.dataGridView_702.Rows.Add(702, 12, "呂心慈");
            this.dataGridView_702.Rows.Add(702, 13, "呂琳暄");
            this.dataGridView_702.Rows.Add(702, 14, "洪少瑄");
            this.dataGridView_702.Rows.Add(702, 15, "許姿涵");
            this.dataGridView_702.Rows.Add(702, 16, "許雅涵");
            this.dataGridView_702.Rows.Add(702, 17, "陳美婷");
            this.dataGridView_702.Rows.Add(702, 18, "劉惠云");
            this.dataGridView_702.Rows.Add(702, 19, "蔡睿庭");
            this.dataGridView_702.Rows.Add(702, 20, "蔡筱君");



            // 801
            this.dataGridView_801.Rows.Add(801, 1, "呂昱瑋");
            this.dataGridView_801.Rows.Add(801, 2, "李少白");
            this.dataGridView_801.Rows.Add(801, 3, "辛炫正");
            this.dataGridView_801.Rows.Add(801, 4, "林均祐");
            this.dataGridView_801.Rows.Add(801, 5, "洪寓穠");
            this.dataGridView_801.Rows.Add(801, 6, "高守信");
            this.dataGridView_801.Rows.Add(801, 7, "許閎棣");
            this.dataGridView_801.Rows.Add(801, 8, "蔡承諺");
            this.dataGridView_801.Rows.Add(801, 9, "呂沂純");
            this.dataGridView_801.Rows.Add(801, 10, "李采芮");
            this.dataGridView_801.Rows.Add(801, 11, "李閔宜");
            this.dataGridView_801.Rows.Add(801, 12, "林靚雯");
            this.dataGridView_801.Rows.Add(801, 13, "洪敏馨");
            this.dataGridView_801.Rows.Add(801, 14, "郭映媗");
            this.dataGridView_801.Rows.Add(801, 15, "陳羿辰");
            this.dataGridView_801.Rows.Add(801, 16, "陳  芊");
            this.dataGridView_801.Rows.Add(801, 17, "歐珮瑀");
            this.dataGridView_801.Rows.Add(801, 18, "顏岑玲");
            this.dataGridView_801.Rows.Add(801, 19, "吳佳豪");
            this.dataGridView_801.Rows.Add(801, 20, "李東澤");



            // 802
            this.dataGridView_802.Rows.Add(802, 1, "王鴻銘");
            this.dataGridView_802.Rows.Add(802, 2, "呂家忠");
            this.dataGridView_802.Rows.Add(802, 3, "許丞宥");
            this.dataGridView_802.Rows.Add(802, 4, "許家杰");
            this.dataGridView_802.Rows.Add(802, 5, "許軒銘");
            this.dataGridView_802.Rows.Add(802, 6, "陳俊翔");
            this.dataGridView_802.Rows.Add(802, 7, "蔡明峰");
            this.dataGridView_802.Rows.Add(802, 8, "李宜臻");
            this.dataGridView_802.Rows.Add(802, 9, "林昕誼");
            this.dataGridView_802.Rows.Add(802, 10, "洪惠英");
            this.dataGridView_802.Rows.Add(802, 11, "洪煊妮");
            this.dataGridView_802.Rows.Add(802, 12, "陳宥琦");
            this.dataGridView_802.Rows.Add(802, 13, "曾佩妤");
            this.dataGridView_802.Rows.Add(802, 14, "劉于瑄");
            this.dataGridView_802.Rows.Add(802, 15, "劉怡婷");
            this.dataGridView_802.Rows.Add(802, 16, "顏詩宜");
            this.dataGridView_802.Rows.Add(802, 17, "林瓊筑");
            this.dataGridView_802.Rows.Add(802, 18, "翁于庭");


            // 901
            this.dataGridView_901.Rows.Add(901, 1, "成芳价");
            this.dataGridView_901.Rows.Add(901, 2, "李哲安");
            this.dataGridView_901.Rows.Add(901, 3, "洪世埕");
            this.dataGridView_901.Rows.Add(901, 4, "洪宗傑");
            this.dataGridView_901.Rows.Add(901, 5, "洪昱霖");
            this.dataGridView_901.Rows.Add(901, 6, "洪祉豪");
            this.dataGridView_901.Rows.Add(901, 7, "洪偉強");
            this.dataGridView_901.Rows.Add(901, 8, "莊子和");
            this.dataGridView_901.Rows.Add(901, 9, "許宏馳");
            this.dataGridView_901.Rows.Add(901, 10, "許倚薰");
            this.dataGridView_901.Rows.Add(901, 11, "許庭閤");
            this.dataGridView_901.Rows.Add(901, 12, "趙奕鈞");
            this.dataGridView_901.Rows.Add(901, 13, "蔡睿祐");
            this.dataGridView_901.Rows.Add(901, 14, "朱怡梅");
            this.dataGridView_901.Rows.Add(901, 15, "吳佳恩");
            this.dataGridView_901.Rows.Add(901, 16, "吳思璇");
            this.dataGridView_901.Rows.Add(901, 17, "林玉婷");
            this.dataGridView_901.Rows.Add(901, 18, "林欣諭");
            this.dataGridView_901.Rows.Add(901, 19, "洪郁琳");
            this.dataGridView_901.Rows.Add(901, 20, "洪楷茵");
            this.dataGridView_901.Rows.Add(901, 21, "洪燕庭");
            this.dataGridView_901.Rows.Add(901, 22, "許雅惠");
            this.dataGridView_901.Rows.Add(901, 23, "陳子曦");
            this.dataGridView_901.Rows.Add(901, 24, "盧雨晴");

            // 902
            this.dataGridView_902.Rows.Add(902, 1, "吳俊彥");
            this.dataGridView_902.Rows.Add(902, 2, "呂彥箴");
            this.dataGridView_902.Rows.Add(902, 3, "呂政翰");
            this.dataGridView_902.Rows.Add(902, 4, "林志翰");
            this.dataGridView_902.Rows.Add(902, 5, "翁翊泰");
            this.dataGridView_902.Rows.Add(902, 6, "許勝凱");
            this.dataGridView_902.Rows.Add(902, 7, "陳嘉樂");
            this.dataGridView_902.Rows.Add(902, 8, "黃乙宸");
            this.dataGridView_902.Rows.Add(902, 9, "楊景豐");
            this.dataGridView_902.Rows.Add(902, 10, "趙世意");
            this.dataGridView_902.Rows.Add(902, 11, "劉晉源");
            this.dataGridView_902.Rows.Add(902, 12, "蔡宇竣");
            this.dataGridView_902.Rows.Add(902, 13, "王奕茜");
            this.dataGridView_902.Rows.Add(902, 14, "成佳瑄");
            this.dataGridView_902.Rows.Add(902, 15, "林芸亘");
            this.dataGridView_902.Rows.Add(902, 16, "洪羽彤");
            this.dataGridView_902.Rows.Add(902, 18, "趙筱榆");
            this.dataGridView_902.Rows.Add(902, 19, "劉怡妏");
            this.dataGridView_902.Rows.Add(902, 20, "劉雨柔");
            this.dataGridView_902.Rows.Add(902, 21, "歐家伊");
            this.dataGridView_902.Rows.Add(902, 22, "歐姵廷");

        }

        //
        int count = 1;

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView_final.Rows.Clear();
            count = 1;
        }


        private void dataGridView_701_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            string A = dataGridView_701.Rows[e.RowIndex].Cells[0].Value.ToString();
            string B = dataGridView_701.Rows[e.RowIndex].Cells[1].Value.ToString();
            string C = dataGridView_701.Rows[e.RowIndex].Cells[2].Value.ToString();
            dataGridView_final.Rows.Add(count.ToString() ,A, B, C);
            count++;
        }

        private void dataGridView_702_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            string A = dataGridView_702.Rows[e.RowIndex].Cells[0].Value.ToString();
            string B = dataGridView_702.Rows[e.RowIndex].Cells[1].Value.ToString();
            string C = dataGridView_702.Rows[e.RowIndex].Cells[2].Value.ToString();
            dataGridView_final.Rows.Add(count.ToString(), A, B, C);
            count++;
        }

        private void dataGridView_801_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            string A = dataGridView_801.Rows[e.RowIndex].Cells[0].Value.ToString();
            string B = dataGridView_801.Rows[e.RowIndex].Cells[1].Value.ToString();
            string C = dataGridView_801.Rows[e.RowIndex].Cells[2].Value.ToString();
            dataGridView_final.Rows.Add(count.ToString(),A, B, C);
            count++;
        }

        private void dataGridView_802_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
           
            string A = dataGridView_802.Rows[e.RowIndex].Cells[0].Value.ToString();
            string B = dataGridView_802.Rows[e.RowIndex].Cells[1].Value.ToString();
            string C = dataGridView_802.Rows[e.RowIndex].Cells[2].Value.ToString();
            dataGridView_final.Rows.Add(count.ToString(),A, B, C);
            count++;
        }

        private void button_help_Click(object sender, EventArgs e)
        {
            string text_help = "滑鼠點選左邊班級學生\r" + "學生會匯入右邊的表格\r"  + "點選按鈕<複製到剪貼簿>\r" + "會跳出一個Excel檔案就OK啦";
            MessageBox.Show(text_help);
        }

        private void copyAlltoClipboard()
        {
            dataGridView_final.SelectAll();
            DataObject dataObj = dataGridView_final.GetClipboardContent();
            if (dataObj != null)
                Clipboard.SetDataObject(dataObj);
        }
        

        private void button1_Click_1(object sender, EventArgs e)
        {
            copyAlltoClipboard();
            Microsoft.Office.Interop.Excel.Application xlexcel;
            Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
            Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlexcel = new Excel.Application();
            xlexcel.Visible = true;
            xlWorkBook = xlexcel.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
            Excel.Range CR = (Excel.Range)xlWorkSheet.Cells[1, 1];
            CR.Select();
            xlWorkSheet.PasteSpecial(CR, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, true);
        }

        private void dataGridView_901_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            string A = dataGridView_901.Rows[e.RowIndex].Cells[0].Value.ToString();
            string B = dataGridView_901.Rows[e.RowIndex].Cells[1].Value.ToString();
            string C = dataGridView_901.Rows[e.RowIndex].Cells[2].Value.ToString();
            dataGridView_final.Rows.Add(count.ToString(), A, B, C);
            count++;
        }

        private void dataGridView_902_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string A = dataGridView_902.Rows[e.RowIndex].Cells[0].Value.ToString();
            string B = dataGridView_902.Rows[e.RowIndex].Cells[1].Value.ToString();
            string C = dataGridView_902.Rows[e.RowIndex].Cells[2].Value.ToString();
            dataGridView_final.Rows.Add(count.ToString(), A, B, C);
            count++;
        }
    }
}
